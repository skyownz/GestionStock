﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace StockProjet
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        SqlConnection cnx = new SqlConnection("Data Source=localhost;Initial Catalog=GestionStock;Integrated Security=True");

        private void label2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        void remplir()
        {
            
            try
            {
                cnx.Open();
                string rqt = "select * from users";
                SqlDataAdapter da = new SqlDataAdapter(rqt, cnx);
                SqlCommandBuilder builder = new SqlCommandBuilder(da);
                DataSet ds = new DataSet();
                da.Fill(ds);
                usergv.DataSource = ds.Tables[0];
                cnx.Close();
            }
            catch
            {
                
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (usernametxt.Text == "" || fullnametxt.Text == "" || passwordtxt.Text == "" || emailtxt.Text == ""|| usernametxt.Text == "UserName" || fullnametxt.Text == "FullName" || passwordtxt.Text == "Password" || emailtxt.Text == "Email")
            {
                MessageBox.Show("Infos invalide!");
            }
            else
            {
                try
                {
                    cnx.Open();
                    SqlCommand cmd = new SqlCommand("insert into users values('" + usernametxt.Text + "','" + fullnametxt.Text + "','" + passwordtxt.Text + "','" + emailtxt.Text + "')", cnx);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Ajouter avec succes!");
                    cnx.Close();
                    remplir();
                }
                catch
                {

                }
            }
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (usernametxt.Text == "")
            {
                MessageBox.Show("Entrer Username");
            }
            else
            {
                try
                {
                    cnx.Open();
                    SqlCommand cmd = new SqlCommand("delete from users where username='" + usernametxt.Text + "'", cnx);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Supprimer avec succes!");
                    cnx.Close();
                    remplir();
                }
                catch
                {

                }
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (usernametxt.Text == "" || fullnametxt.Text == "" || passwordtxt.Text == "" || emailtxt.Text == "" || usernametxt.Text == "UserName" || fullnametxt.Text == "FullName" || passwordtxt.Text == "Password" || emailtxt.Text == "Email")
            {
                MessageBox.Show("Infos invalide!");
            }
            else
            {
                try
                {
                    cnx.Open();
                    SqlCommand cmd = new SqlCommand("update users set username='" + usernametxt.Text + "',fullname='" + fullnametxt.Text + "',userpw='" + passwordtxt.Text + "',email='" + emailtxt.Text + "' where username='" + usernametxt.Text + "'", cnx);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Editer avec succes!");
                    cnx.Close();
                    remplir();
                }
                catch
                {

                }
            }

        }

        private void Form2_Load(object sender, EventArgs e)
        {
            remplir();
        }

        private void usernametxt_Enter(object sender, EventArgs e)
        {
            usernametxt.Text = "";
        }

        private void fullnametxt_Enter(object sender, EventArgs e)
        {
            fullnametxt.Text = "";
        }

        private void passwordtxt_Enter(object sender, EventArgs e)
        {
            passwordtxt.Text = "";
        }

        private void emailtxt_Enter(object sender, EventArgs e)
        {
            emailtxt.Text = "";
        }

        private bool mouseDown;
        private Point lastLocation;

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            mouseDown = true;
            lastLocation = e.Location;
        }

        private void panel1_MouseMove(object sender, MouseEventArgs e)
        {
            if (mouseDown)
            {
                this.Location = new Point(
                    (this.Location.X - lastLocation.X) + e.X, (this.Location.Y - lastLocation.Y) + e.Y);

                this.Update();
            }
        }

        private void panel1_MouseUp(object sender, MouseEventArgs e)
        {
            mouseDown = false;
        }

    }
}
